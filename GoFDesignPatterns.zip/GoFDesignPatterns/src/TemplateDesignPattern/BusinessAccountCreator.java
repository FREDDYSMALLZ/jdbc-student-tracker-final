package TemplateDesignPattern;

public class BusinessAccountCreator extends AccountCreator {
    @Override
    public void generateAccountNumber() {
        System.out.println("Business Account number generated");
    }

}
