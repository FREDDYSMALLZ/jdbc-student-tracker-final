package TemplateDesignPattern;

public class Exec {
    public static void main(String[] args) {
        AccountCreator ac = new BusinessAccountCreator();
        ac.createAccount();
        AccountCreator pac = new PrivateAccountCreator();
        pac.createAccount();
    }
}
