package FactoryDesignPattern;

import static FactoryDesignPattern.Mobile.*;

public class Exec {
    public static void main(String[] args) {
        Mobile mobile = MobileFactory.createMobile(SAMSUNG);
        Mobile mobile1 = MobileFactory.createMobile(IPHONE);
        Mobile mobile2 = MobileFactory.createMobile(SONY);

        System.out.println("These are the Phones Created:");
        System.out.println(Mobile.SAMSUNG);
        System.out.println(Mobile.IPHONE);
        System.out.println(Mobile.SONY);

    }
}
