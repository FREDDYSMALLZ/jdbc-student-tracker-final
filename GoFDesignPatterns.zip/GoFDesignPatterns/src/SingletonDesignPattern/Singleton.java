package SingletonDesignPattern;

public class Singleton {

    //Create Singleton Object
    private static Singleton instance = new Singleton();

    //Make the constructor Private not to be instantiated in any way
    private Singleton(){
        System.out.println("Testing Singleton...");

    }
    //Get the object available
    public  static Singleton getInstance(){
        return instance;
    }

}
