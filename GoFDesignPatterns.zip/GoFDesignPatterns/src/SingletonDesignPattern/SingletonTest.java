package SingletonDesignPattern;

public class SingletonTest {
    public static void main(String[] args) {

        Singleton instance = Singleton.getInstance();
        Singleton instance1 = Singleton.getInstance();
        Singleton instance2 = Singleton.getInstance();
        Singleton instance3 = Singleton.getInstance();

        print("instance",instance);
        print("instanc1",instance1);
        print("instanc2",instance2);
        print("instance3",instance3);
        

    }

    public static void print(String name, Singleton object) {

        System.out.println(String.format("Object : %s, Hascode: %d", name, object.hashCode()));

    }





}
