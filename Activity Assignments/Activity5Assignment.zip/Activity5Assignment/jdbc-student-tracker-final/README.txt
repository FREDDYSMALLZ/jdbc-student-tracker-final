Student Tracker Application using JSF-
========================================
This directory contains the source code and SQL script for the Student tracker Application
I have updated the application from the previous versions.
> Version 1: contains only the code for listing students

> Version 2: builds on version 1 and adds code for adding students

> Version 3: builds on version 2 and adds code for updating students

> Version 4: builds on version 3 and adds code deleting students

> This is the Final Version: contains combination of all versions



